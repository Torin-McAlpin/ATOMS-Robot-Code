# Welcome
Welcome to the NextFTC Quickstart! It has NextFTC & PedroPathing integration built in.

---

Check out the NextFTC Docs: <https://docs.rowanmcalpin.com/>  
Check out the PedroPathing Docs: <https://pedropathing.com/>  

Join the NextFTC Discord: <https://discord.gg/PjP9Ze6fkX>  
Join the PedroPathing Discord: <https://discord.gg/2GfC4qBP5s>  
